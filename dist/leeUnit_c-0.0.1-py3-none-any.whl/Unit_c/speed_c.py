# 킬로미터/시 <-> 마일/시
def kph_to_mph(kph):
    return kph * 0.621371

def mph_to_kph(mph):
    return mph / 0.621371

# 미터/초 <-> 킬로미터/시
def mps_to_kph(mps):
    return mps * 3.6

def kph_to_mps(kph):
    return kph / 3.6

# 미터/초 <-> 마일/시
def mps_to_mph(mps):
    return mps * 2.23694

def mph_to_mps(mph):
    return mph / 2.23694